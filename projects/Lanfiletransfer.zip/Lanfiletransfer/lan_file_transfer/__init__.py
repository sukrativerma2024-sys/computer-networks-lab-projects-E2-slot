# LAN File Transfer System
# A cross-platform file transfer application for local networks
